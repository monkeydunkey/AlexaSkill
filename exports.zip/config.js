module.exports = {
    API_ENDPOINT:'https://www.tunefind.com/api/v1/show/',
    API_USERNAME: '10eddcdacf826f3a6eccfe2b742eb3d3',
    API_KEY:'cde36d48cbc90a76701f9cc7c0022f40',
    HASH_AUTH_VALUE: 'MTBlZGRjZGFjZjgyNmYzYTZlY2NmZTJiNzQyZWIzZDM6Y2RlMzZkNDhjYmM5MGE3NjcwMWY5Y2M3YzAwMjJmNDA=',
    YES_INTENT: 'AMAZON.YesIntent',
    NO_INTENT: 'AMAZON.NoIntent',
    CANCEL_INTENT: 'AMAZON.CancelIntent',
    STOP_INTENT: 'AMAZON.StopIntent',
    HELP_INTENT: 'AMAZON.HelpIntent',
    OBJECT_TVSHOW: 'tvshow',
}
